import React from "react";
import Nav from "./Nav";
import Search from "./Search"

import "../sources/css/warehousing.css"

export default function Warehousing(){

    return(
        <>
        <Search/>
        <div style={{display:"flex"}}>
        <Nav/>
        <div className="btn1">
            <h1>입고내역</h1>
        <button className="qrbtn"></button>
        <div className="btn2">
            <h1>입고상품</h1>
        <button className="qrbtn"></button>
        </div>

        </div>
        </div>
        
        </>

    )
}

