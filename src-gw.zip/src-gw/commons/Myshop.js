import React from "react";
import Nav from "./Nav";
import Search from "./Search"
import "../sources/css/myshop.css"

export default function Myshop(){

    return(
        <>
        <Search/>
        <div style={{display:"flex"}}>
        <Nav/>
        <div className="outline">
            <h1 className="title">SSGTARBUCKS</h1>
            <h4>
            <label for="id">지점이름</label>
            </h4>
            <input type="text" id="id"></input>
            <h4>
            <label for="id">지점주소</label>
            </h4>
            <input className="address" type="text" id="address"></input>
            <h4>
            <label for="e-mail">e-mail</label>
            </h4>
            <input type="e-mail" id="e-mail"></input>
            <h4>
            <label for="number">사원번호</label>
            </h4>
            <input type="text" id="number"></input>
            <h4>
            <label for="number">휴대번호</label>
            </h4>
            <input type="text" id="number"></input>
        </div>
        </div>
        
        </>
    )
}