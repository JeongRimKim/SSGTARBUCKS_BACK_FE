import "../sources/css/nav.css";
import { useState } from "react";


export default function Nav(){
    let [isActive, setIsActive] = useState(false);
    console.log("nav", isActive);

    return(
        <>
            <nav style={(isActive ? {width : "3%"} : {width : "8%"})}>
                <div className="content">
                    <div id="menu">
                        <a href="/set_position" className="menu_link">
                            <div className="menu_itm">
                                <i className="fa-solid fa-qrcode fa-lg menu_icon"></i>
                                { !isActive && 
                                <span className="menu_name">
                                    기준정보
                                </span>
                                }
                            </div>
                        </a>
                        <a href="#" className="menu_link">
                            <div className="menu_itm">
                                <i className="fa-solid fa-truck fa-lg menu_icon"></i>
                                { !isActive &&
                                <span className="menu_name">
                                    입고관리
                                </span>
                                }
                            </div>
                        </a>
                        <a href="#" className="menu_link">
                            <div className="menu_itm">
                                <i className="fa-solid fa-warehouse fa-lg menu_icon"></i>
                                { !isActive &&
                                    <span className="menu_name">
                                        재고관리
                                    </span>
                                }
                            </div>
                        </a>
                        <a href="#" className="menu_link">
                            <div className="menu_itm">
                                <i className="fa-solid fa-arrow-left fa-lg menu_icon"></i>
                                { !isActive &&
                                    <span className="menu_name">
                                        출고관리
                                    </span>
                                }
                            </div>
                        </a>
                        <a href="#" className="menu_link">
                            <div className="menu_itm">
                                <i className="fa-solid fa-house fa-lg menu_icon"></i>
                                { !isActive &&
                                    <span className="menu_name">
                                        지점정보
                                    </span>
                                }
                            </div>
                        </a>
                    </div>
                    <hr style={{width:"100%", margin:"20px"}}></hr>
                    { !isActive &&
                        <div>
                            <a href="#">
                                <span className="menu_name">
                                    로그아웃
                                </span>
                            </a>
                        </div>
                    }
                    <div onClick={
                        ()=>{
                            // let parent = e.target.parentNode.parentNode;
                            // parent.parentNode.setAttribute("style", "width : 3%");
                            setIsActive(isActive=>!isActive);
                        }
                    }>
                        <i className={`fa-solid fa-caret-${(isActive ? "up" : "down")} fa-lg toggle_icon`} ></i>
                    </div>
                </div>
            </nav>
        </>
    )
}