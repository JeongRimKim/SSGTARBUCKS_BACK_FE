import React,{useState} from "react";
import '../sources/css/signup.css'

export default function Signup(){

    let [modal, setModal] = useState(false);
    let [modal2, setModal2] = useState(false);
    console.log(modal);

    return(
        <div>
        <div className="circle"></div>
        <div className="card">
            <h2>SSGTARBUCKS</h2><br/>
            <h4>비밀번호 찾기</h4>
        
            <div className="logo">
            </div>
            <div className="form">
                <input type="text" placeholder="사원번호"/>
                <input type="e-mail" placeholder="e-mail"/><button type="submit" onClick={()=>{setModal(!modal);}}>인증번호 발송</button>
            </div>
            <div className={modal ? "form" : "form1" }>
                <input type="text" placeholder="인증번호"/><button type="submit" onClick={()=>{setModal2(!modal2);}}>인증번호 확인</button>
            </div>
            <form className={modal2 ? "form" : "form2" }>
                <input type="password" placeholder="비밀번호"/>
                <input type="password" placeholder="비밀번호 확인"/><button type="submit" >비밀번호 변경</button>
                
            </form>
            <footer>
                
            <button className="backbutton" type="submit">BACK</button>

            </footer>
        </div>
        </div>

    )
}
