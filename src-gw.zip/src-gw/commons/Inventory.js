import React from "react";
import Nav from "./Nav";
import Search from "./Search"
import '../sources/css/inventory.css'


export default function Inventory(){

    return(
        <>
        <Search/>
        <div style={{display:"flex"}}>
        <Nav/>
        <div className="btn1">
            <h1>보관상품</h1>
        <button className="qrbtn"></button>
        <div className="btn2">
            <h1>보관장소</h1>
        <button className="qrbtn"></button>
        </div>

        </div>
        </div>
        
        </>

    )
}