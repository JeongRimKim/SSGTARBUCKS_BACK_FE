import React, { useState } from "react";
import Nav from "./Nav";
import Search from "./Search";
import '../sources/css/salelist.css';
import axios from 'axios';


export default function Salelist(){

    const [list,setList] = useState([]);

    return(
        <>
        <Search/>
        <div style={{display:"flex"}}>
        <Nav/>
        <div className="outline">
        <div className="salelist">
            <div className="getbtn">
            <table className="listtable">
                <div className="flex0">
                <div className="flex0">
                <td className="h_number">번호</td>
                </div>
                <div className="flex0">
                <td className="h_p_name">제품명</td>
                </div>
                <div className="flex0">
                <td className="h_delete">
                    <button className="updatebtn"
                            onClick={()=>[
                                axios.get('https://sw-devr.github.io/data.json')
                                .then((response)=>{
                                console.log(response.data)
                                setList(response.data);
                                
                                })
                                .catch(()=>{
                                    console.log('데이터를 가져오지 못했습니다.')
                                })
                            ]}>업데이트</button></td>
                </div>
                </div>
            {list.map(function(r,index){
                return(
                <tr className="list">
                    <div className="flex">
                    <div className="flex">
                    <td className="number">{r.product_id}</td>
                    </div>
                    <div className="flex">
                    <td className="p_name">{r.product_name}</td>
                    </div>
                    <div className="flex">
                    <td className="delete"><button className="deletebtn">삭제</button></td>
                    </div>
                    </div>
                </tr>
            )})}
            </table>
            </div>
        </div>
        </div>
        </div>
        
        </>


    )
}
