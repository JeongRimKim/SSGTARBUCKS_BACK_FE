import React from "react";
import '../sources/css/release.css'

export default function Release(){

    return(
        <>
        <Search/>
        <div style={{display:"flex"}}>
        <Nav/>
        <div className="btn1">
            <h1>사용등록</h1>
        <button className="qrbtn"></button>
        <div className="btn2">
            <h1>폐기등록</h1>
        <button className="qrbtn"></button>
        </div>

        </div>
        </div>
        
        </>

    )
}