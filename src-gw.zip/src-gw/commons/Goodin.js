import React from "react";
import Nav from "./Nav";
import Search from "./Search"

import "../sources/css/goodin.css"


export default function Goodin(){

    return(
        <>
        <Search/>
        <div style={{display:"flex"}}>
        <Nav/>
        <div className="btn1">
            <h1>입고등록</h1>
        <button className="qrbtn"></button>
        </div>
        </div>
        </>
    )
}

