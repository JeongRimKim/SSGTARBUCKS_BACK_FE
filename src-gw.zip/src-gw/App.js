import logo from './logo.svg';
import './App.css';
import Nav from './commons/Nav.js';
import Salelist from './commons/Salelist.js';
import axios from 'axios';


function App() {
  return (
    <div className="App">
      <Salelist/>
    </div>
  );
}

export default App;
